package pset5;

public class C
{
    int max(int x, int y)
    {
        if (x < y)
        {
            return y;
        } else return x;
    }
}
